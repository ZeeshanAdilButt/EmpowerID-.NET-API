﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ActivityApp.Application.Core.Common
{
    public static class APIErrorConstants
    {
        public const string generalError = "Something went wrong, Please contact support and refer to this error Id: ";
    }
}
