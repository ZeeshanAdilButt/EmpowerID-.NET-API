﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ActivityApp.Application.Core.ApplicationContracts.Requests.Example
{
    public class UpdateActivityParticipantRequest : BaseRequest
    {
        public int Id { get; set; }
       public CreateParticipantRequest Participant { get; set; }
    }
}
