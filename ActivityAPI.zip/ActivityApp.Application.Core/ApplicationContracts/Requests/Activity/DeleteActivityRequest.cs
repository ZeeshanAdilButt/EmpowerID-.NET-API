﻿using System;

namespace ActivityApp.Application.Core.ApplicationContracts.Requests.Activity
{
    public class GetActivityRequest : BaseRequest
    {
        public int Id { get; set; }

    }
}
