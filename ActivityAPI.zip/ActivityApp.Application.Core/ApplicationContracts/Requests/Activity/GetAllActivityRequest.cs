﻿using System;

namespace ActivityApp.Application.Core.ApplicationContracts.Requests.Example
{
    public class GetAllActivityRequest : BaseRequest
    {
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
    }
}
