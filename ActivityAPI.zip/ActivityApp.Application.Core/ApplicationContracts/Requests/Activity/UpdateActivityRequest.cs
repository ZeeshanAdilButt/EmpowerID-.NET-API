﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ActivityApp.Application.Core.ApplicationContracts.Requests.Example
{
    public class UpdateActivityRequest : BaseRequest
    {
        [Required]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string Description { get; set; }
        [Required]
        public DateTime Date { get; set; }
        [Required]
        public string Address { get; set; }
        public double Longitude { get; set; }
        public double Latitude { get; set; }

    }
}
