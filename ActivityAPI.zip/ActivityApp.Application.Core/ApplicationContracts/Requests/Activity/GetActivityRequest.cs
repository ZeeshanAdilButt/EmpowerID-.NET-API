﻿using System;

namespace ActivityApp.Application.Core.ApplicationContracts.Requests.Activity
{
    public class DeleteActivityRequest : BaseRequest
    {
        public int Id { get; set; }

    }
}
