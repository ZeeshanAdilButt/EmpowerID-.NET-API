﻿using System.ComponentModel.DataAnnotations;

namespace ActivityApp.Application.Core.ApplicationContracts.Requests.Example
{
    public class CreateParticipantRequest : BaseRequest
    {
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
    }
}
