﻿using ActivityApp.Application.Core.ApplicationContracts.Common;
using System;
using System.Collections.Generic;

namespace ActivityApp.Application.Core.ApplicationContracts.Responses.Example
{
    public class GetActivityResponse : GenericResponse
    {
        public GetActivityResponse()
        {
            Participants = new List<GetParticipantResponse>();
        }
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime Date { get; set; }
        public string Address { get; set; }


        public double Longitude { get; set; }
        public double Latitude { get; set; }
        public List<GetParticipantResponse> Participants { get; set; }

    }
}
