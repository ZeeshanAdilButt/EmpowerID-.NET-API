﻿using ActivityApp.Application.Core.ApplicationContracts.Common;

namespace ActivityApp.Application.Core.ApplicationContracts.Responses.Example
{
    public class CreateActivityResponse : GenericResponse
    {
        public CreateActivityResponse(int id)
        {
            Id = id;
        }

        public CreateActivityResponse()
        {

        }

        public int Id { get; set; }
       
    }
}
