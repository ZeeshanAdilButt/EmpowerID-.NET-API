﻿using ActivityApp.Application.Core.ApplicationContracts.Common;
using System;
using System.Collections.Generic;

namespace ActivityApp.Application.Core.ApplicationContracts.Responses.Example
{
    public class GetAllActivityResponse : GenericResponse
    {
        public List<GetActivityResponse> Data;
    }
}
