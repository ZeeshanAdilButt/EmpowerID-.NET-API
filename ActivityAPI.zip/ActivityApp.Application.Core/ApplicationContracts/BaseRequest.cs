﻿namespace ActivityApp.Application.Core.ApplicationContracts
{
    public class BaseRequest
    {
    }

}
