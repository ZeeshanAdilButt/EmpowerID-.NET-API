﻿namespace ActivityApp.Application.Core.Enum
{
    public enum RoleEnum
    {
        Admin = 1,
        User = 2
    }
}
