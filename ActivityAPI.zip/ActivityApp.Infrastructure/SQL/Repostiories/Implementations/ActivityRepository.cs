﻿using Microsoft.EntityFrameworkCore;
using ActivityApp.Infrastructure.SQL;
using ActivityApp.Infrastructure.SQL.Repostiories.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ActivityApp.Domain.Data;
using System;

namespace ActivityApp.Infrastructure.SQL.Repostiories.Implementations
{
    public class ActivityRepository : IActivityRepository
    {

        ApplicationDbContext _context;

        public ActivityRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<int> CreateAsync(Activity acticvity)
        {
            _context.Activities.Add(acticvity);
            return await _context.SaveChangesAsync();
        }

        public async Task<bool> DeleteActivityAsync(int Id)
        {
            var entity = _context.Activities.FirstOrDefault(x => x.Id == Id);

            if (entity != null)
            {
                _context.Remove(entity);
                return true;
            }
            else throw new ApplicationException("Activity with provided ID does not exist");

        }

        public async Task<Activity> GetActivityAsync(int Id)
        {
            return await _context.Activities
                .Include(x=>x.Participants).FirstOrDefaultAsync(x => x.Id == Id);
        }

        public async Task<List<Activity>> GetAllActivityAsync(DateTime? fromDate, DateTime? toDate)
        {

            var response = _context.Activities.Where(x => x.IsActive == true).AsQueryable();

            if (fromDate != null)
                response = response.Where(x => x.Date >= fromDate);

            if (toDate != null)
                response = response.Where(x => x.Date <= toDate);

            return await response.ToListAsync();
        }

        public async Task<Activity> UpdateAsync(Activity entity)
        {
            var activity = await _context.Activities.AsNoTracking().FirstOrDefaultAsync(x => x.Id == entity.Id);

            if (activity == null)
                throw new ApplicationException("Activity with provided ID does not exist");

            _context.Activities.Update(entity);
            await _context.SaveChangesAsync();

            return entity;
        }

        public async Task<Activity> UpdateParticipantAsync(int Id, Participant participant)
        {
            var activity = await _context.Activities.FirstOrDefaultAsync(x => x.Id == Id);

            if (activity == null)
                throw new ApplicationException("Activity with provided ID does not exist");

            activity.Participants.Add(participant);

            _context.Update(activity);
            await _context.SaveChangesAsync();

            return activity;
        }
    }
}
