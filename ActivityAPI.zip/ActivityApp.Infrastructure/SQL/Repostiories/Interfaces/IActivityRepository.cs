﻿using ActivityApp.Domain.Data;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ActivityApp.Infrastructure.SQL.Repostiories.Interfaces
{
    public interface IActivityRepository
    {
        Task<int> CreateAsync(Activity acticvity);
        Task<bool> DeleteActivityAsync(int Id);
        Task<Activity> GetActivityAsync(int Id);
        Task<List<Activity>> GetAllActivityAsync(DateTime? fromDate, DateTime? toDate);
        Task<Activity> UpdateAsync(Activity entity);
        Task<Activity> UpdateParticipantAsync(int Id, Participant participant);
    }
}