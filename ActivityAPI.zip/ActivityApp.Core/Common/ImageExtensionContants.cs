﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ActivityApp.Core.Common
{
    public class ImageExtensionContants
    {
        public const string JPG = ".jpg";
        public const string JPEG = ".jpeg";
        public const string GIF = ".gif";
        public const string PNG = ".png";
    }
}
