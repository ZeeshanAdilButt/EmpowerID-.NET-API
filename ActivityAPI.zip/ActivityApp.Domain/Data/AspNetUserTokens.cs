﻿using Microsoft.AspNetCore.Identity;

namespace ActivityApp.Domain.Data
{
    public partial class AspNetUserTokens:IdentityUserToken<string>
    {
    }
}
