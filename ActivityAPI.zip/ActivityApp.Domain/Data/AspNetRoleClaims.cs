﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;

namespace ActivityApp.Domain.Data
{
    public partial class AspNetRoleClaims: IdentityRoleClaim<string>
    {
       

    }
}
