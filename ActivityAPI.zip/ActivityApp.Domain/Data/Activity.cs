﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace ActivityApp.Domain.Data
{
    public partial class Activity
    {
        public Activity()
        {
            Participants = new List<Participant>();
        }
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime Date { get; set; }
        [Required]
        public string Address { get; set; }
        public double Longitude { get; set; }
        public double Latitude { get; set; }
        public bool IsActive { get; set; } = true;
        public virtual List<Participant> Participants { get; set; }

    }
}
