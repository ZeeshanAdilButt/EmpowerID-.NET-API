﻿using Microsoft.AspNetCore.Identity;

namespace ActivityApp.Domain.Data
{
    public partial class AspNetUserRoles:IdentityUserRole<string>
    {

    }
}
