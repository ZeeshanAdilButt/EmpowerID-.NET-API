﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using ActivityApp.Application.Core.APIController;
using ActivityApp.Application.Core.Exceptions;
using ActivityApp.Application.Implementations;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ActivityApp.Application.Core.ApplicationContracts.Requests.Example;
using ActivityApp.Application.Core.ApplicationContracts.Responses.Example;
using ActivityApp.Application.Core.ApplicationContracts.Requests.Activity;

namespace ActivityApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ActivityController : APIBaseController
    {
        private readonly IActivityService _ActivityService;

        public ActivityController(
            IActivityService ActivityService,
            IHttpContextAccessor httpContextAccessor,
            IConfiguration configuration,
            ILogger<ActivityController> logger) : base(httpContextAccessor, configuration, logger)
        {
            _ActivityService = ActivityService;
        }

        
        [HttpGet]
        public async Task<IActionResult> Getall([FromQuery] GetAllActivityRequest request)
        {
            try
            {

                GetAllActivityResponse response = await _ActivityService.GetAllActivityAsync(request);

                return base.HandleResponse(response);

            }
            catch (Exception ex)
            {
                var errorResult = ex.GetErrorResponse(_currentUser);

                return BadRequest(errorResult);
            }
        }

        [HttpGet("{Id}")]
        //[SwaggerOperation(Summary = "get exmaple description here")]
        public async Task<IActionResult> Get([FromRoute] GetActivityRequest request)
        {
            try
            {
                GetActivityResponse response = await _ActivityService.GetActivityAsync(request);

                return base.HandleResponse(response);

            }
            catch (Exception ex)
            {
                var errorResult = ex.GetErrorResponse(_currentUser);

                return BadRequest(new
                {
                    result = errorResult
                });
            }
        }

        /// <summary>
        /// exmaple description here
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        // POST: api/Activity/Create
        [HttpPost]
        [SwaggerOperation(Summary = "create exmaple description here")]
        public async Task<IActionResult> Post([FromBody] CreateActivityRequest request)
        {
            try
            {
                CreateActivityResponse response = await _ActivityService.CreateAsync(request);

                return base.HandleResponse(response);
            }
            catch (Exception ex)
            {
                var errorResult = ex.GetErrorResponse(_currentUser);

                return BadRequest(new
                {
                    result = errorResult
                });
            }
        }

        /// <summary>
        /// exmaple description here
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        // POST: api/Activity/Create
        [HttpPut]
        [SwaggerOperation(Summary = "create exmaple description here")]
        public async Task<IActionResult> Update([FromBody] UpdateActivityRequest request)
        {
            try
            {
                UpdateActivityResponse response = await _ActivityService.UpdateAsync(request);

                return base.HandleResponse(response);
            }
            catch (Exception ex)
            {
                var errorResult = ex.GetErrorResponse(_currentUser);

                return BadRequest(new
                {
                    result = errorResult
                });
            }
        }

        /// <summary>
        /// exmaple description here
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        // POST: api/Activity/Create
        [HttpPut("UpdateParticipant")]
        [SwaggerOperation(Summary = "create exmaple description here")]
        public async Task<IActionResult> UpdateParticipant([FromBody] UpdateActivityParticipantRequest request)
        {
            try
            {
                UpdateActivityResponse response = await _ActivityService.UpdateActivityParticipantAsync(request);

                return base.HandleResponse(response);
            }
            catch (Exception ex)
            {
                var errorResult = ex.GetErrorResponse(_currentUser);

                return BadRequest(new
                {
                    result = errorResult
                });
            }
        }
    }
}
