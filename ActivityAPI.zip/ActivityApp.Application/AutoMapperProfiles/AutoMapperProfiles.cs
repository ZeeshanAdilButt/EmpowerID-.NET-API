﻿using ActivityApp.Application.Core.ApplicationContracts.Requests.Activity;
using ActivityApp.Application.Core.ApplicationContracts.Requests.Example;
using ActivityApp.Application.Core.ApplicationContracts.Responses.Example;
using ActivityApp.Domain.Data;
using AutoMapper;

namespace ActivityApp.Application.AutoMapperProfiles
{
    public class AutoMapperProfiles : Profile
    {
        public AutoMapperProfiles()
        {
            #region Request DTOs Registration

            #region Example Controller

            CreateMap<CreateActivityRequest, Activity>();
            
            CreateMap<Activity, CreateActivityRequest>();

            CreateMap<UpdateActivityRequest, Activity>();

            CreateMap<Activity, GetActivityResponse>();
            CreateMap<Activity, CreateActivityResponse>();
            CreateMap<Activity, UpdateActivityResponse>();

            #endregion

            #endregion
        }
    }
}
