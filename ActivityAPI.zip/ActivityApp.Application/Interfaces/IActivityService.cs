﻿using ActivityApp.Application.Core.ApplicationContracts.Common;
using ActivityApp.Application.Core.ApplicationContracts.Requests.Activity;
using ActivityApp.Application.Core.ApplicationContracts.Requests.Example;
using ActivityApp.Application.Core.ApplicationContracts.Responses.Example;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ActivityApp.Application.Implementations
{
    public interface IActivityService
    {
        Task<GetAllActivityResponse> GetAllActivityAsync(GetAllActivityRequest data);
        Task<GenericResponse> DeleteActivityAsync(DeleteActivityRequest request);
        Task<CreateActivityResponse> CreateAsync(CreateActivityRequest data);
        Task<GetActivityResponse> GetActivityAsync(GetActivityRequest request);
        Task<UpdateActivityResponse> UpdateAsync(UpdateActivityRequest request);
        Task<UpdateActivityResponse> UpdateActivityParticipantAsync(UpdateActivityParticipantRequest request);
    }
}