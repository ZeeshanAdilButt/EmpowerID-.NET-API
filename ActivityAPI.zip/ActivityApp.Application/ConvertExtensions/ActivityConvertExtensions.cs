﻿using ActivityApp.Application.Core.ApplicationContracts.Requests.Example;
using ActivityApp.Application.Core.ApplicationContracts.Responses.Example;
using ActivityApp.Domain.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActivityApp.Application.ConvertExtensions
{
    public static class ActivityConvertExtensions
    {
        public static GetActivityResponse Convert(this Activity activity)
        {
            return new GetActivityResponse
            {
                Id = activity.Id,
                Name = activity.Name,
                Description = activity.Description,
                Address = activity.Address,
                Date = activity.Date,
                Longitude = activity.Longitude,
                Latitude = activity.Latitude,
                Participants = activity.Participants?.Select(participant => participant.Convert()).ToList()

            };
        }

        public static GetParticipantResponse Convert(this Participant participant)
        {
            return new GetParticipantResponse
            {
                Id = participant.Id,
                FirstName = participant.FirstName,
                LastName = participant.LastName,
            };
        }

        public static Activity Convert(this UpdateActivityRequest request)
        {
            return new Activity
            {
                Id = request.Id,
                Name = request.Name,
                Description = request.Description,
                Address = request.Address,
                Date = request.Date,
                Longitude = request.Longitude,
                Latitude = request.Latitude,
            };
        }

        public static UpdateActivityResponse ConvertUpdate(this Activity updatedEntity)
        {
            return new UpdateActivityResponse
            {
                Id = updatedEntity.Id,
                Name = updatedEntity.Name,
                Description = updatedEntity.Description,
                Date = updatedEntity.Date,
                Longitude = updatedEntity.Longitude,
                Latitude = updatedEntity.Latitude,
                IsActive = updatedEntity.IsActive,
                Participants = updatedEntity.Participants?.Select(x => new GetParticipantResponse
                {
                    Id = x.Id,
                    FirstName = x.FirstName,
                    LastName = x.LastName,
                }).ToList(),

            };
        }

        public static UpdateActivityResponse ConvertUpdatedParticipant(this Activity updatedEntity)
        {
            return new UpdateActivityResponse
            {
                Id = updatedEntity.Id,
                Name = updatedEntity.Name,
                Description = updatedEntity.Description,
                Date = updatedEntity.Date,
                Longitude = updatedEntity.Longitude,
                Latitude = updatedEntity.Latitude,
                IsActive = updatedEntity.IsActive,
                Participants = updatedEntity.Participants?.Select(x => new GetParticipantResponse
                {
                    Id = x.Id,
                    FirstName = x.FirstName,
                    LastName = x.LastName,
                }).ToList(),

            };
        }
    }
}
