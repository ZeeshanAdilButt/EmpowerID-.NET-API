﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using ActivityApp.Application.Common;
using ActivityApp.Infrastructure.SQL.Repostiories.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;
using ActivityApp.Application.Core.ApplicationContracts.Responses.Example;
using ActivityApp.Application.Core.ApplicationContracts.Requests.Example;
using AutoMapper;
using ActivityApp.Domain.Data;
using ActivityApp.Application.Core.ApplicationContracts.Requests.Activity;
using ActivityApp.Application.Core.ApplicationContracts.Common;
using System.Linq;
using System;
using ActivityApp.Application.ConvertExtensions;

namespace ActivityApp.Application.Implementations
{
    public class ActivityService : BaseService, IActivityService
    {
        private readonly IActivityRepository _ActivityRepository;
        private readonly IMapper _mapper;

        public ActivityService(IMapper mapper, IActivityRepository ActivityRepository, IHttpContextAccessor httpContextAccessor, IConfiguration configuration) : base(httpContextAccessor, configuration)
        {
            _mapper = mapper;
            this._ActivityRepository = ActivityRepository;
        }

        public async Task<CreateActivityResponse> CreateAsync(CreateActivityRequest request)
        {
            try
            {
                Activity data = new Activity
                {
                    Name = request.Name,
                    Description = request.Description,
                    Date = request.Date,
                    Address = request.Address,
                    Latitude = request.Latitude,
                    Longitude = request.Longitude,
                };

                await _ActivityRepository.CreateAsync(data);

                return new CreateActivityResponse(data.Id);
            }
            catch (System.Exception ex)
            {

                return new CreateActivityResponse
                {
                    OriginalException = ex,
                    IsSuccess = false

                };
            }

        }
        public async Task<GenericResponse> DeleteActivityAsync(DeleteActivityRequest request)
        {
            try
            {
                await _ActivityRepository.DeleteActivityAsync(request.Id);

                return new GenericResponse { IsSuccess = true };
            }
            catch (System.Exception ex)
            {

                return new GenericResponse { IsSuccess = false, OriginalException = ex };

            }

        }

        public async Task<GetActivityResponse> GetActivityAsync(GetActivityRequest request)
        {
            try
            {
                var response = await _ActivityRepository.GetActivityAsync(request.Id);

                if (response == null)
                    throw new ApplicationException("Activity with provided ID does not exist");
                
                return response.Convert();
            }
            catch (System.Exception ex)
            {
                return new GetActivityResponse { OriginalException = ex };
            }

        }


        public async Task<GetAllActivityResponse> GetAllActivityAsync(GetAllActivityRequest request)
        {
            try
            {
                var response = await _ActivityRepository.GetAllActivityAsync(request.FromDate, request.ToDate);


                return new GetAllActivityResponse
                {
                    IsSuccess = true,
                    Data = response.Select(activity => activity.Convert()).ToList()
                };
            }
            catch (System.Exception ex)
            {

                return new GetAllActivityResponse { OriginalException = ex };
            }

        }

        public async Task<UpdateActivityResponse> UpdateAsync(UpdateActivityRequest request)
        {
            try
            {
                Activity requestentity = request.Convert();

                Activity updatedEntity = await _ActivityRepository.UpdateAsync(requestentity);

                return updatedEntity.ConvertUpdate();

            }
            catch (System.Exception ex)
            {
                return new UpdateActivityResponse
                {
                    OriginalException = ex
                };
            }
        }

        public async Task<UpdateActivityResponse> UpdateActivityParticipantAsync(UpdateActivityParticipantRequest request)
        {
            try
            {
                Participant participant = new Participant
                {
                    FirstName = request.Participant.FirstName,
                    LastName = request.Participant.LastName,
                };

                Activity updatedEntity = await _ActivityRepository.UpdateParticipantAsync(request.Id, participant);
                
                return updatedEntity.ConvertUpdatedParticipant();

            }
            catch (System.Exception ex)
            {
                return new UpdateActivityResponse
                {
                    OriginalException = ex
                };
            }
        }
    }
}
